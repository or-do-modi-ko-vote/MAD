package com.example.pract11;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class MainActivity extends AppCompatActivity {

    TextView tvResult;
    Button btnFetch;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvResult = findViewById(R.id.tvResult);
        btnFetch = findViewById(R.id.btnFetch);

        btnFetch.setOnClickListener(v -> {

            tvResult.setText("Loading...");

            new Thread(() -> {

                try {

                    URL url = new URL(
                            "https://jsonplaceholder.typicode.com/users/1");

                    HttpURLConnection con =
                            (HttpURLConnection) url.openConnection();

                    BufferedReader br =
                            new BufferedReader(
                                    new InputStreamReader(
                                            con.getInputStream()));

                    String line, data = "";

                    while ((line = br.readLine()) != null)
                        data += line;

                    JSONObject obj = new JSONObject(data);

                    String result =
                            "ID : " + obj.getInt("id") +
                                    "\nName : " + obj.getString("name") +
                                    "\nEmail : " + obj.getString("email");

                    runOnUiThread(() ->
                            tvResult.setText(result));

                } catch (Exception e) {

                    runOnUiThread(() ->
                            tvResult.setText("Error Loading Data"));

                }
            }).start();
        });
    }
}
