
package com.example.calculator;

import android.os.Bundle;
import android.util.Log;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    EditText n1, n2;
    TextView result;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);

        n1 = findViewById(R.id.n1);
        n2 = findViewById(R.id.n2);
        result = findViewById(R.id.result);

        findViewById(R.id.add).setOnClickListener(v -> calc('+'));
        findViewById(R.id.sub).setOnClickListener(v -> calc('-'));
        findViewById(R.id.mul).setOnClickListener(v -> calc('*'));
        findViewById(R.id.div).setOnClickListener(v -> calc('/'));
    }

    void calc(char op) {
        String first = n1.getText().toString().trim();
        String second = n2.getText().toString().trim();

        if (first.isEmpty() || second.isEmpty()) {
            Toast.makeText(this, "Enter both numbers",
                    Toast.LENGTH_SHORT).show();
            return;
        }

        double a, b, r;

        try {
            a = Double.parseDouble(first);
            b = Double.parseDouble(second);
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Enter valid numbers",
                    Toast.LENGTH_SHORT).show();
            return;
        }

        if (op == '/' && b == 0) {
            result.setText("Cannot divide by zero");
            return;
        }

        if (op == '+') {
            r = a + b;
        } else if (op == '-') {
            r = a - b;
        } else if (op == '*') {
            r = a * b;
        } else {
            r = a / b;
        }

        result.setText("Result: " + r);
        Log.d("Calculator", "Result = " + r);
    }
}
