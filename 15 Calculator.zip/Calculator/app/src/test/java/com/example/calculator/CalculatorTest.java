
package com.example.calculator;

import org.junit.Test;
import static org.junit.Assert.assertEquals;

public class CalculatorTest {

    Calculator c = new Calculator();

    @Test
    public void addition() {
        assertEquals(15, c.add(10, 5));
    }

    @Test
    public void subtraction() {
        assertEquals(5, c.subtract(10, 5));
    }

    @Test
    public void multiplication() {
        assertEquals(50, c.multiply(10, 5));
    }

    @Test
    public void division() {
        assertEquals(2, c.divide(10, 5));
    }
}
