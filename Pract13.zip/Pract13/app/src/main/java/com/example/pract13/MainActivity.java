
package com.example.pract13;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    ImageView imageView;
    MediaPlayer mp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        imageView = findViewById(R.id.imageView);

        Button btnAnimate = findViewById(R.id.btnAnimate);
        Button btnPlay = findViewById(R.id.btnPlay);
        Button btnPause = findViewById(R.id.btnPause);
        Button btnStop = findViewById(R.id.btnStop);

        mp = MediaPlayer.create(this, R.raw.song);

        btnAnimate.setOnClickListener(v -> {
            imageView.animate()
                    .rotationBy(360)
                    .translationX(100)
                    .alpha(0.5f)
                    .setDuration(1000)
                    .start();
        });

        btnPlay.setOnClickListener(v -> {
            if (mp != null) {
                if (!mp.isPlaying()) {
                    mp.start();
                }
            }
        });

        btnPause.setOnClickListener(v -> {
            if (mp != null && mp.isPlaying()) {
                mp.pause();
            }
        });

        btnStop.setOnClickListener(v -> {
            if (mp != null) {
                mp.release();
            }

            mp = MediaPlayer.create(this, R.raw.song);
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        if (mp != null) {
            mp.release();
            mp = null;
        }
    }
}
